import './dongyi.css';
import Issue from './Issue';
import Issue_detail from './Issue_detail';
import { DongyiProvider, useDongyi } from './DongyiContext';

// 동협 담당: 이슈관리
function IssueRoute() {
  const { projects, issues, setIssues } = useDongyi();
  return <Issue projects={projects} issues={issues} setIssues={setIssues} />;
}
function IssueDetailRoute() {
  const { projects, issues } = useDongyi();
  return <Issue_detail projects={projects} issues={issues} />;
}

export const Provider = DongyiProvider;

export const shellRoutes = [
  { path: '/issue', element: <IssueRoute /> },
  { path: '/issue/:id', element: <IssueDetailRoute /> },
];
